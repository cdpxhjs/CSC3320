1. python file name: pythoncreate.py
	run with: python pythoncreate.py
2. C file name: ccreate.c
	run with: gcc ccreate.c -o ccreate
	./ccreate
   Creator file name: createfile.c
	run with: gcc create.c -o create
	./create test
3. Origin commands are in FINALinstruction.sh
	run with: bash ./FINALinstruction.sh
	origin output: output
	converted output: FINALinstruction
4. wrote in Q3.
5. source code in Q5.py
   sorted file list of "FINALinstruction"
	run with python Q5.py
6. source code in /FINALc/copies/Q6.c
	run with gcc Q6.c -o Q6
	./Q6
7. source code in /FINALpython/copies/Q7.py
	run with python Q7.py
8. source code in /FINALc/encrypted/Q8.c
	run with gcc Q8.c -o Q8
	./Q8
	***However, the decrypted file do has the origin non-encrypted contents, but followed by weird words.
	***In Question 9, runs in python, there is no such a problem. 
9. source code in /FINALpython/encrypted/Q9.py
	run with python Q9.py
