#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<memory.h>

int main(int argc, char** argv)
{
	char *str1 = calloc(sizeof("/home/jhuang24/Final/FINALc/")+sizeof(argv[1])+1,sizeof *str1);
	strcpy(str1,"touch /home/jhuang24/Final/FINALc/");
	strcat(str1,argv[1]);
	system(str1);
	return 0;
}
