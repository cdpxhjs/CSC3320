import os

def encrypt(text):
    result = ""
    for i in range(len(text)):
      char = text[i]
      result += chr((ord(char) + 150) % 256)
    return result

for filename in os.listdir(os.getcwd()):
    with open(os.path.join(os.getcwd(),filename), 'rb') as f:
        binary_file = f.read()
        bb = encrypt(binary_file)
        ff = open("/home/jhuang24/Final/FINALpython/encrypted/"+filename,"wb")
        ff.write(bb)
        ff.close()

