import os

def decrypt(text):
    result = ""
    for i in range(len(text)):
      char = text[i]
      if char >= 150:
        result += chr((ord(char) - 150) % 256)
      else:#another loop
        result += char((ord(char) + 256 -150) % 256)
    return result

for filename in os.listdir(os.getcwd()):
    with open(os.path.join(os.getcwd(),filename), 'rb') as f:
        binary_file = f.read()
        bb = decrypt(binary_file)
        ff = open("/home/jhuang24/Final/FINALpython/decrypted/"+filename,"wb")
        ff.write(bb)
        ff.close()
