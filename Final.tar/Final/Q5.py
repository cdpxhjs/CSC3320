from os import system

system("awk '{if($1 != 'total'){print $2}}' FINALinstruction >> Q5Files")
system("xargs -a Q5Files cp -t /home/jhuang24/Final/FINALc/copies")
system("xargs -a Q5Files cp -t /home/jhuang24/Final/FINALpython/copies")
