1. python file name: pythoncreate.py
	run with: python pythoncreate.py
2. C file name: ccreate.c
	run with: gcc ccreate.c -o ccreate
	./ccreate
   Creator file name: createfile.c
	run with: gcc create.c -o create
	./create test
3. Origin commands are in FINALinstruction.sh
	run with: bash ./FINALinstruction.sh
	origin output: output
	converted output: FINALinstruction
