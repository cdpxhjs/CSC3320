from os import system
system("mkdir FINALpython")
system("cp pythoncreate.py FINALpython")
system("mkdir -p /home/jhuang24/Final/FINALpython/copies")
system("mkdir -p /home/jhuang24/Final/FINALpython/encrypted")
system("mkdir -p /home/jhuang24/Final/FINALpython/decrypted")

