#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

int main()
{
    char ch, file_name[25];
    FILE *fp;
    int key;
    //char letter[26] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
    char content[9999];
    int index = 0;

    printf("Enter name of a file you wish to read\n");
    gets(file_name);//read the file name
    printf("Enter the key\n");
    scanf("%d", &key);
    fp = fopen(file_name, "r");//read mode

    if(fp==NULL)
    {
        perror("Error while opening the file.\n");
        exit(EXIT_FAILURE);
    }

    printf("Reading File: ",file_name);
                                                                               
    while((ch=fgetc(fp))!=EOF)
    {
        content[index]=ch;
        index++;
    }
    fclose(fp);
 
   int length = strlen(content);
   int i,j;

   for (i = 0; i < length; i++)
   {
       if((content[i]>='a' && content[i]<='z') || (content[i]>='A' && content[i]<='Z'))//if word with in the range from a-z and A-Z
       {
            if ((content[i]>='z'-key && content[i]<='z') || (content[i] >= 'Z' - key && content[i] <= 'Z')) // if the index exceed the a-z/A-Z limit
            {
                 content[i] = content[i] - 26 + key;//switch the index to the beginning
            }
            else//within the range
            {
                 content[i] = content[i] + key;
            }
       }
   }

   for (j = 0; j < length;j++)
   {
       content[j] = tolower(content[j]);
   }
   printf("%s", content);
   printf("\n");
   return 0;
}
