COMMANDS:
1. Source code can be seen in "encrypt.c" and "encrypt" is runable program.
   gcc -o encrypt encrypt.c
   ./encrypt >> Q1Answer
   message1.txt
   9


2.Source code can be seen in "encrypt2.c" and "encrypt2" is runable program.
  gcc -o encrypt2 encrypt2.c
  ./encrypt2 >> Q2Answer
  ceaser1.txt


3.Source code can be seen in "encrypt3.c" and "encrypt3" is runable program.
  gcc -o encrypt3 encrypt3.c
  ./encrypt3 >> Q3Answer
  ceaser2.txt
