raw_a=input("Enter a line to convert to an integer: ")
a=int(raw_a)
print(a)
#print(type(a))
