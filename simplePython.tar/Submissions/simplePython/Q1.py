a = input("Enter a line: ")
print(a)
