#include<stdio.h>

int main()
{
    char sen[500];
    printf("Enter a line: ");
    scanf("%s", sen);
    printf("You entered: %s\n", sen);
    return 0;
}