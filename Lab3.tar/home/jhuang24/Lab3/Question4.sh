#! /bin/bash

echo "The mean of x:"
mean7= awk '{if ($1=="HETATM") sum+=$7} END{if(NR>0) print sum/NR}' /home/jhuang24/Lab3/4HKD.pdb

echo "The mean of y:"
mean8= awk '{if ($1=="HETATM") sum+=$8} END{if(NR>0) print sum/NR}' /home/jhuang24/Lab3/4HKD.pdb

echo "The mean of z:"
mean9= awk '{if ($1=="HETATM") sum+=$9} END{if(NR>0) print sum/NR}' /home/jhuang24/Lab3/4HKD.pdb
