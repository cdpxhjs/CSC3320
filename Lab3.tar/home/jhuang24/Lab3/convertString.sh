#! /bin/bash

awk '
{
sign=0; 
if(substr($0,1,1)=="-") 
{sign=1};

gsub("-","",$0);
split($0,num,"/");
knuts=(num[1]*23 + num[2])*17 + num[3];
if (sign==1)
{knuts=-knuts};
print knuts;
}' /home/jhuang24/Lab3/lab3data.txt
