#! /bin/bash

echo "minimum of x: "
min7= awk 'BEGIN{a=1000}{if (($1=="ATOM")&&($7<0+a)) a=$7} END{print a}' /home/jhuang24/Lab3/4HKD.pdb
echo "minimum of y: "
min8= awk 'BEGIN{a=1000}{if (($1=="ATOM")&&($8<0+a)) a=$8} END{print a}' /home/jhuang24/Lab3/4HKD.pdb
echo "minimum of z: "
min9= awk 'BEGIN{a=1000}{if (($1=="ATOM")&&($9<0+a)) a=$9} END{print a}' /home/jhuang24/Lab3/4HKD.pdb

echo "maximum of x: "
max7= awk 'BEGIN{a=0}{if (($1=="ATOM")&&($7>0+a)) a=$7} END{print a}' /home/jhuang24/Lab3/4HKD.pdb
echo "maximum of y: "
max8= awk 'BEGIN{a=0}{if (($1=="ATOM")&&($8>0+a)) a=$8} END{print a}' /home/jhuang24/Lab3/4HKD.pdb
echo "maximum of z: "
max9= awk 'BEGIN{a=0}{if (($1=="ATOM")&&($9>0+a)) a=$9} END{print a}' /home/jhuang24/Lab3/4HKD.pdb

