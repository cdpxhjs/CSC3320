#! /bin/bash

awk '{
sign=0;
if (substr($0,1,1)=="-")
{sign=1};
if (substr($0,1,1)!="-")
{sign=0};
gsub("-","",$0);
galleons=int($0/(23*17));
rem=$0%(23*17);
sickles=int(rem/17);
knuts=rem%17;
if(sign==1)
{galleons=-galleons};
result=galleons "/" sickles "/" knuts;
print result;
}' /home/jhuang24/Lab3/Problem3

