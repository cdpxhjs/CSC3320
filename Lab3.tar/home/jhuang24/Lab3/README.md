COMMANDS USED FOR LAB 3
1. grep -ivE "ATOM|CONECT|HETATM|TER|END" 4HKD.pdb >> Quesition1
2. sed 's/HETATM/ATOM  /g; s/MSE/MET/g' 4HKD.pdb >> Question2
3. All the commands are written in "Question3.sh" script. can use"bash ./Question3.sh" to see the result.
4. All the commands are written in "Question4.sh" script. can use"bash ./Question4.sh" to see the result.
5. sed 's/HOH/WAT/g' 4HKD.pdb >> Question5
6. STEP1: Catch all line that start with string "ATOM":
   grep "^ATOM" 4HKD.pdb >> Question6Ori
   STEP2: Sort these data according to column 11:
   sort -k 11 Question6Ori >> Question6

PART II
1. All the commands are written in "convertString.sh" script. can use"bash ./convertString.sh" to see the result.
   The result of Problem1 was saved in "Problem1" by using "bash ./convertString.sh >> Problem1".
2. All the commands are written in "convertNum.sh" script, can use"bash ./convertNum.sh" to see the result.
   The result of Problem2 was saved in "Problem2" by using "bash ./convertNum.sh >> Problem2".
3. All the commands are written in "sumNum.sh" script, can use"bash ./sumNum.sh" to see the result.
   The result of Problem3 was saved in "Problem3" by using "bash ./sumNum.sh >> Problem3".
4. Change the path in the script of Problem2 from "/home/jhuang24/Lab3/Problem1" to "/home/jhuang24/Lab3/Problem3"
   and the new script was saved as "Problem4.sh". can use"bash ./Problem4.sh" to see the result.
   The result of Problem4 was saved in "Problem4" by using "bash ./Problem4.sh >> Problem4".
