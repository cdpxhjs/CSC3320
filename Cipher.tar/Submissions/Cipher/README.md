1.  python Q1.py >> Q1Answer
    message1.txt
    9

2. python Q2.py >> Q2Answer
   ceaser1.txt

3. python Q3.py >> Q3Answer
   ceaser2.txt
